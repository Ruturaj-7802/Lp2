#include<bits/stdc++.h>
using namespace std;

bool isSafe(int row, int col, vector < string > board, int n) {
    // check upper element
    int duprow = row;
    int dupcol = col;
    while (row >= 0 && col >= 0) {
        if (board[row][col] == 'Q')
            return false;
        row--;
        col--;
    }
    col = dupcol;
    row = duprow;
    while (col >= 0) {
        if (board[row][col] == 'Q')
            return false;
        col--;
    }
    row = duprow;
    col = dupcol;
    while (row < n && col >= 0) {
        if (board[row][col] == 'Q')
            return false;
        row++;
        col--;
    }
    return true;
}

void solve(vector<string> &board, vector<vector<string>> &ans, int n, int col){
    if(col == n) {
        ans.push_back(board);
        return;
    }
    int row = col;
    for(int i=0;i<n;i++){
        if(isSafe(i, col, board, n)){
            board[i][col] = 'Q';
            solve(board, ans, n, col+1);
            board[i][col] = '.'; // backtracking
        }
    }
    return;
}

int main(){
    int n; cin >> n;
    string s(n, '.');
    vector<string> board(n);
    vector<vector<string>> ans;
    for(int i=0;i<n;i++) board[i] = s;
    solve(board, ans, n, 0);
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cout << ans[i][j] << endl;
        }
        cout << endl;
    }
    return 0;
}